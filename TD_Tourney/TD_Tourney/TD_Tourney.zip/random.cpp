#include "random.h"


random::random(int first_val, int last_val)
{
	name = "Random [";
	logging = true;

	first = first_val;
	last = last_val;

	char temp[32];	// buffer to hold k string below
	_itoa_s (first_val, temp, 10);	// change the first value to a string
	name.append(temp);

	name.append(", ");

	_itoa_s (last_val, temp, 10);	// change the last value to a string
	name.append(temp);

	name.append("]");

	string filename = name;
	filename.append(".txt");
	log.open(filename.c_str());
}


random::~random(void)
{
}

int random::getBid_Extended()
{
	return (rand() % (1+last-first)) + first;
}