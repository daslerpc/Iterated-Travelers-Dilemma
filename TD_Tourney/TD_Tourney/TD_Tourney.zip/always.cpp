#include "always.h"


always::always(int x)
{
	logging = true;
	always_num = max(min(x, 100), 2);
	char temp[4];	// buffer to hold "always" string below

	name = "Always ";
	
	_itoa_s (x, temp, 10);	// change the "always" value to a string
	name.append(temp);

	string filename = name;
	filename.append(".txt");
	log.open(filename.c_str());
}

//If this constructor gets called, then we forgot to initialize this instance
always::always(void)
{
	always_num = -1;
	name = "Always Unitialized";
}


always::~always(void)
{
}


int always::getBid_Extended()
{
	return always_num;
}

