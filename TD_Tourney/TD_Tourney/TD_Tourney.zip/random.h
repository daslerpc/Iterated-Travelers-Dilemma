#pragma once
#include "traveler.h"
class random :
	public traveler
{
public:
	random(int first=2, int last=100);
	~random(void);

	int getBid_Extended();

	int first;
	int last;
};

