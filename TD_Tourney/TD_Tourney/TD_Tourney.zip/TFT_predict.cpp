#include "TFT_predict.h"

#include <iostream>


TFT_predict::TFT_predict(int strategy)
{
	logging = true;
	first = true;
	
	my_bid = 0;

	a = b = c = d = e = false;

	name = "TFT -";

	switch(strategy)
	{
	case 1: 
		a = true;
		name.append(" low(x) equal(x) high(y-1)");
		break;
	case 2: 
		b = true;
		name.append(" low(x) equal(x-2) high(y-1)");
		break;
	case 3: 
		c = true;
		name.append(" low(x-2) equal(x) high(y-1)");
		break;
	case 4: 
		d = true;
		name.append(" low(x-2) equal(x-2) high(y-1)");
		break;
	case 5: 
		e = true;
		name.append(" low(y-1) equal(x-1) high(x-1)");
		break;
	}
	
	string filename = name;
	filename.append(".txt");
	log.open(filename.c_str());
}

TFT_predict::TFT_predict(bool no_log)
{
	first = true;
	name = "TFT - Predict";

	my_bid = 0;
}


TFT_predict::~TFT_predict(void)
{
}

int TFT_predict::getBid_Extended()
{
	int bid = 0;

	if(first)
	{
		first = false;
		bid = randomBid();
	}
	else
	{
		if(my_bid > opp_bid)
			bid = opp_bid*(a||b||c||d) + my_bid*e - 1;
		else
		{
			if(e)
			{
				if(my_bid < opp_bid)
					bid = max(opp_bid - 1, 2);	
				if(my_bid == opp_bid)
					bid = max(opp_bid - 1, 2);	
			}
			else
			{
				if(my_bid < opp_bid)
					bid = max(my_bid - 2*(c||d), 2);	
				if(my_bid == opp_bid)
					bid = max(my_bid - 2*(b||d), 2);	
			}
		}
	}

	my_bid = bid;
	return bid;
}

void TFT_predict::end_Match_Extended()
{
	my_bid = 0;
	opp_bid = 100;
	first = true;
}