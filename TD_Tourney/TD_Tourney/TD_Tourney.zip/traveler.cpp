#include "traveler.h"

#include <iostream>
#include <string>
#include <fstream> // For file logging


traveler::traveler(void)
{
	pay_out = 0;
	match_sum = 0;
	Utils[0] = 0;
	Utils[1] = 0;
	Utils[2] = 0;
	Utils[3] = 0;

	opp_bid = 0;

	name = "Generic Traveler";
}


traveler::~traveler(void)
{
	if(log.is_open())
		log.close();
}

void traveler::return_Round_Results(int settlement, int opponents_bid)
{
	pay_out = settlement;
	opp_bid = opponents_bid;

	match_sum += settlement;
	Utils[0] += settlement;

	int ideal_payout;
	int ideal_bid = max(2, opponents_bid-1);
	
	if(ideal_bid == opponents_bid)
		ideal_payout = ideal_bid;
	else
		ideal_payout = ideal_bid+2;

	Utils[2] += (double)settlement/(double)ideal_payout;
	Utils[3] += 1.0 - abs((double)my_bid-(double)ideal_bid)/98.0;

	if(logging)
		log << "{" << my_bid << ", " << opp_bid << "} -> (" << settlement << ")\t";
	
	return_Round_Results_Extended(settlement, opponents_bid);

	if(logging)
		log << endl;
}

void traveler::return_Match_Results(int opponents_match_sum)
{
	if(match_sum > opponents_match_sum)
		Utils[1]++;
	else if(match_sum < opponents_match_sum)
		Utils[1]--;
}

void traveler::return_Round_Results_Extended(int settlement, int opponents_bid)
{
}

void traveler::return_Match_Results_Extended(int opponents_match_sum)
{
}


int traveler::getBid()
{
	my_bid = min(100, max(2, getBid_Extended()));
	return my_bid;
}

void traveler::print()
{
	cout << Utils[0] << ":\t" << name << endl;
}

int traveler::getBid_Extended()
{
	return -1; //This value gets wiped out by the range check in getBid
}

void traveler::end_Match()
{
	match_sum = 0;
	end_Match_Extended();
	if(logging)
		log << endl << endl;
}

void traveler::end_Match_Extended()
{
}

void traveler::start_Match(string opponent_name, int match_num)
{
	if(logging)
		log << name << " vs. " << opponent_name << " : Match " << match_num << endl;	

	start_Match_Extended(opponent_name);
}

void traveler::start_Match_Extended(string opponent_name)
{
}

int traveler::randomBid()
{
	return (rand() % 99) + 2;
}

int traveler::matchSum()
{
	return match_sum;
}
