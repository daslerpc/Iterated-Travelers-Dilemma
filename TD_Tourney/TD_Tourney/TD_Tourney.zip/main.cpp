#include <iostream> // For cout
#include <conio.h>  // For _gethch
#include <time.h>	// For timing analysis

#include "tournament.h"


using namespace std;


void main()
{
	clock_t start_time = clock();
	tournament T;
	
	// Add strategies to the competitors list
	T.addCompetitors();

	//Run the tournament
	T.runTournament(100, 1000);

	cout << endl << endl;
	
	clock_t elapsed = clock() - start_time;
	
	cout << "Execution time: " << endl;
	cout <<  (1000.0*elapsed/CLOCKS_PER_SEC)/1000.0 << " seconds." << endl;
	
	cout << endl << endl;
	
	cout << "Press any key to continue.";
	_getch();
}
